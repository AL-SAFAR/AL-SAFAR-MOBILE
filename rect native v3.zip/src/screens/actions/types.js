export const GET_GUIDES = "GET_GUIDES";
export const GET_HOTELS = "GET_HOTELS";
export const SEARCH_HOTELS = "GET_HOTELS";
export const SET_LOADING = "SET_LOADING";
export const GUIDES_ERROR = "GUIDES_ERROR";
export const HOTELS_ERROR = "HOTELS_ERROR";
