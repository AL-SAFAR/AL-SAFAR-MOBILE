import React from "react";
import { View, Text } from "react-native";

const SPRegisterScreen = () => {
  return <View></View>;
};

export default SPRegisterScreen;
