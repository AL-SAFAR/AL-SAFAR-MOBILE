import React, { Component } from "react";
import { StyleSheet, Image, Button, View, Text } from "react-native";
import { createAppContainer, createSwitchNavigator } from "react-navigation";
import {
  Ionicons as Icons,
  FontAwesome as FIcons,
  AntDesign as AD,
  Feather as FeatherIcon
} from "@expo/vector-icons";

import HomeNavigation from "./src/screens/navigations/HomeNavigation";
import GuideNavigation from "./src/screens/navigations/Guide/GuideNavigation";

import Login from "./src/screens/components/Login/Login";
import RegisterScreen from "./src/screens/components/Login/RegisterScreen";

const AppSwitchNavigator = createSwitchNavigator({
  Login: { screen: Login },
  Register: { screen: RegisterScreen },
  Home: { screen: HomeNavigation },
  Guide: { screen: GuideNavigation }
});
export default createAppContainer(AppSwitchNavigator);
